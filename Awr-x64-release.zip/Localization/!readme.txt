I am very interesting in help with localizations. Please mail me prog@progdvb.com
