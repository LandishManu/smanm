You can put Remote control modules to RemoteControl directory or to RemoteControl\*\ 
