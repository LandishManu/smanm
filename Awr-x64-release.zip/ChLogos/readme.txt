This directory contains pictures which are used in ProgDVB as logo for channels.
Pictures can be in one of following formats gif, jpg, png, bmp. 
The picture name should equaled to a channel name (the register is not important). 
One picture can equaled to several channels. For example 
ftv@fashion.gif
As it is possible to use ' ^ ' as any string.
For example
"mtv ^.gif" for all MTV channels.

PS: I am very interested in creation of good base of logos. 