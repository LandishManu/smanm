You can put plugins to root of progdvb or to plugins directory or to plugins\*\ . 
But some plugins can working only in root.

pip01,pip02,...pip16 folders for addition set of plugins. 
They are used if to open more than one channel simultaneously.