Also you can put satellites.xml file with table in xml format. 
For example from http://satellites-xml.org and some other sites.