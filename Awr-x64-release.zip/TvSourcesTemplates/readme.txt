;Supported only api=m3u
api=m3u

ProviderName=name
ProviderComment=Some desctiption
Site=www.progdvb.com

; any string ID or #number 1..7FFF. Uniq for all ProgDVB 
ID=#7FF0
Name=Source  1
Comment=Any test about list.
; disabled by default
Disabled=1
; m3u is last field of link. Name, ID,... must be before
m3u=http://127.0.0.1/one.m3u


ID=#7FF1
Name=Source 2
m3u=http://127.0.0.1:8000/f.m3u8
Guide=http://127.0.0.1:8000/xmltv.xml.gz
Guide=http://127.0.0.1:8000/second.jtv.zip

...